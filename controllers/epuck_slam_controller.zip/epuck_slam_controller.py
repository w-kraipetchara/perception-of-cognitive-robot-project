"""epuck_slam_controller controller."""

from controller import Robot, Keyboard
import numpy as np
import math
import matplotlib.pyplot as plt

# ══════════════════════════════════════════════════════════════════
# ① GraphSLAM Engine (Tutorial Aligned: Omega & Xi)
# ══════════════════════════════════════════════════════════════════
class GraphSLAM:
    def __init__(self, num_landmarks):
        self.num_landmarks = num_landmarks
        self.poses = 1 
        # Initial dimension: (1 pose + N landmarks) * 2 coordinates
        self.dim = (self.poses + num_landmarks) * 2
        self.Omega = np.zeros((self.dim, self.dim))
        self.xi = np.zeros((self.dim, 1))
        # Anchor the first pose at [0,0] [cite: 32]
        self.anchor_pose([0.0, 0.0])

    def anchor_pose(self, pos):
        """Sets the starting point constraint[cite: 7]."""
        for i in range(2):
            self.Omega[i, i] += 1e6 
            self.xi[i, 0] += 1e6 * pos[i]

    def expand_graph(self):
        """Tutorial Logic: Dynamically grow the state vector."""
        self.poses += 1
        new_dim = (self.poses + self.num_landmarks) * 2
        new_Omega = np.zeros((new_dim, new_dim))
        new_xi = np.zeros((new_dim, 1))

        # Copy old pose data
        old_pose_end = (self.poses - 1) * 2
        new_Omega[:old_pose_end, :old_pose_end] = self.Omega[:old_pose_end, :old_pose_end]
        new_xi[:old_pose_end] = self.xi[:old_pose_end]

        # Shift Landmark data to the new end of the matrix [cite: 7]
        lm_old_idx = old_pose_end
        lm_new_idx = self.poses * 2
        new_Omega[lm_new_idx:, lm_new_idx:] = self.Omega[lm_old_idx:, lm_old_idx:]
        new_xi[lm_new_idx:] = self.xi[lm_old_idx:]

        self.Omega, self.xi = new_Omega, new_xi

    def add_constraint(self, i, j, vec, sigma):
        """The core update rule from the Sarrocco Tutorial."""
        weight = 1.0 / (sigma + 1e-9)
        for k in range(2):
            idx_i = i * 2 + k
            idx_j = j * 2 + k
            # Omega updates 
            self.Omega[idx_i, idx_i] += weight
            self.Omega[idx_j, idx_j] += weight
            self.Omega[idx_i, idx_j] -= weight
            self.Omega[idx_j, idx_i] -= weight
            # Xi updates [cite: 9]
            self.xi[idx_i, 0] -= vec[k] * weight
            self.xi[idx_j, 0] += vec[k] * weight

    def solve(self):
        """Solves Omega * mu = xi."""
        try:
            mu = np.linalg.solve(self.Omega, self.xi)
            return mu.reshape(-1, 2)
        except:
            return np.linalg.lstsq(self.Omega, self.xi, rcond=None)[0].reshape(-1, 2)

# ══════════════════════════════════════════════════════════════════
# ② Setup & Hardware
# ══════════════════════════════════════════════════════════════════
robot = Robot()
timestep = int(robot.getBasicTimeStep())
keyboard = Keyboard()
keyboard.enable(timestep)

# Devices [cite: 31, 32]
left_motor = robot.getDevice('left wheel motor')
right_motor = robot.getDevice('right wheel motor')
left_motor.setPosition(float('inf'))
right_motor.setPosition(float('inf'))

left_ps = robot.getDevice('left wheel sensor')
right_ps = robot.getDevice('right wheel sensor')
left_ps.enable(timestep)
right_ps.enable(timestep)

lidar = robot.getDevice('lidar')
lidar.enable(timestep)
lidar.enablePointCloud()

# SLAM State
NUM_LANDMARKS = 10
slam = GraphSLAM(num_landmarks=NUM_LANDMARKS)
x, y, theta = 0.0, 0.0, 0.0
last_l, last_r = 0.0, 0.0
accumulated_dist = 0.0
dr_path = [[0.0, 0.0]]

# Setup Visualization Window
plt.ion()
fig, ax = plt.subplots()

# ══════════════════════════════════════════════════════════════════
# ③ Main Control Loop
# ══════════════════════════════════════════════════════════════════
while robot.step(timestep) != -1:
    # 1. Odometry [cite: 35, 36]
    cl, cr = left_ps.getValue(), right_ps.getValue()
    dl = (cl - last_l) * 0.0205
    dr = (cr - last_r) * 0.0205
    last_l, last_r = cl, cr

    dist = (dl + dr) / 2.0
    d_theta = (dr - dl) / 0.052
    
    dx, dy = dist * math.cos(theta), dist * math.sin(theta)
    x, y, theta = x + dx, y + dy, theta + d_theta
    dr_path.append([x, y])
    accumulated_dist += abs(dist)

    # 2. Trigger SLAM Update (Every 5cm of movement)
    if accumulated_dist > 0.05:
        slam.expand_graph()
        curr_node = slam.poses - 1
        # Movement Constraint [cite: 51]
        slam.add_constraint(curr_node - 1, curr_node, [dx, dy], 0.05)
        
        # Landmark Constraints (from Lidar) [cite: 49, 50]
        pc = lidar.getPointCloud()
        if pc:
            # Pick a distinct point (closest wall) [cite: 16]
            valid_pts = [p for p in pc if 0.1 < math.sqrt(p.x**2 + p.y**2) < 2.5]
            if valid_pts:
                p = valid_pts[0]
                # Simple ID assignment by angle [cite: 19]
                lm_id = int((math.atan2(p.y, p.x) + math.pi) / (2*math.pi) * NUM_LANDMARKS) % NUM_LANDMARKS
                slam.add_constraint(curr_node, slam.poses + lm_id, [p.x, p.y], 0.1)
        
        accumulated_dist = 0.0

        # Update Live Map
        mu = slam.solve()
        slam_path = mu[:slam.poses]
        lms = mu[slam.poses:]
        
        ax.clear()
        ax.plot(np.array(dr_path)[:,0], np.array(dr_path)[:,1], 'm--', label='Dead Reckoning', alpha=0.5)
        ax.plot(slam_path[:,0], slam_path[:,1], 'b-', label='SLAM Path', linewidth=2)
        ax.scatter(lms[:,0], lms[:,1], c='red', marker='x', label='Walls')
        ax.legend()
        ax.set_aspect('equal')
        plt.draw()
        plt.pause(0.001) # Small pause to allow window to update

    # 3. WASD Controls
    key = keyboard.getKey()
    ls, rs = 0.0, 0.0
    if key == ord('W'): ls = rs = 5.0
    elif key == ord('S'): ls = rs = -5.0
    elif key == ord('A'): ls, rs = -2.5, 2.5
    elif key == ord('D'): ls, rs = 2.5, -2.5
    left_motor.setVelocity(ls)
    right_motor.setVelocity(rs)